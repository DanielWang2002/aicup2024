# aicup2024
# 環境配置
先略過
# 使用方法
```python
python ./main.py
```
# 專案結構
```
.
├── LSTM                        # LSTM實驗結果
├── aicup_empty_answer.csv      # upload.csv
├── catboost_info               # catboost自動生成緩存資料夾
├── concat.csv                  # 經過資料清洗後整合完的資料
├── data_loader.py              # 提供讀取資料的功能
├── data_preprocessing.py       # 處理外部資料
├── feature_engineering.py      # 使用OpenFE做特徵工程
├── location_azimuths.csv       # 
├── main.py
├── model_training.py
├── openfe_tmp_data.feather
├── scaling.py
├── solar_angles_10min.csv
├── solar_azimuths.csv
├── submission.csv
├── submission.py
├── test_data_preprocessing.py
└── utils.py
```